import Parser from 'rss-parser'

const parser = new Parser({ timeout: 8000 })
const FEEDS = [
  { source: 'Agência Brasil', url: 'https://agenciabrasil.ebc.com.br/rss/ultimasnoticias/feed.xml', region: 'Brasil' },
  { source: 'BBC News Brasil', url: 'https://feeds.bbci.co.uk/portuguese/rss.xml', region: 'Mundo' }
]

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600')
  res.setHeader('Access-Control-Allow-Origin', '*')

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Método não permitido' })
  }

  const results = await Promise.allSettled(FEEDS.map(async (feed) => {
    const parsed = await parser.parseURL(feed.url)
    return (parsed.items || []).map((item) => ({
      title: item.title || 'Notícia sem título',
      link: item.link || '',
      description: (item.contentSnippet || item.content || '').replace(/<[^>]*>/g, '').slice(0, 420),
      pubDate: item.isoDate || item.pubDate || null,
      source: feed.source,
      region: feed.region
    }))
  }))

  const articles = results
    .filter((result) => result.status === 'fulfilled')
    .flatMap((result) => result.value)
    .filter((item) => item.link && item.title)
    .sort((a, b) => new Date(b.pubDate || 0) - new Date(a.pubDate || 0))
    .slice(0, 40)

  if (!articles.length) {
    return res.status(502).json({
      articles: [],
      error: 'Não foi possível carregar os feeds de notícias neste momento'
    })
  }

  return res.status(200).json({ articles, updatedAt: new Date().toISOString() })
}
