import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { Search, Globe2, Newspaper, RefreshCw, WifiOff, ArrowUpRight, Download, CheckCircle2 } from 'lucide-react'
import './styles.css'

function App() {
  const [articles, setArticles] = useState([])
  const [query, setQuery] = useState('')
  const [region, setRegion] = useState('Todas')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [offline, setOffline] = useState(!navigator.onLine)
  const [installPrompt, setInstallPrompt] = useState(null)
  const [installed, setInstalled] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(null)

  useEffect(() => {
    const onOnline = () => setOffline(false)
    const onOffline = () => setOffline(true)
    const onBeforeInstall = (event) => {
      event.preventDefault()
      setInstallPrompt(event)
    }
    const onInstalled = () => {
      setInstalled(true)
      setInstallPrompt(null)
    }

    window.addEventListener('online', onOnline)
    window.addEventListener('offline', onOffline)
    window.addEventListener('beforeinstallprompt', onBeforeInstall)
    window.addEventListener('appinstalled', onInstalled)

    if ('serviceWorker' in navigator && import.meta.env.PROD) {
      navigator.serviceWorker.register('/service-worker.js').catch((err) => {
        console.warn('Não foi possível registrar o service worker:', err)
      })
    }

    loadNews()
    const timer = window.setInterval(loadNews, 5 * 60 * 1000)
    return () => {
      window.clearInterval(timer)
      window.removeEventListener('online', onOnline)
      window.removeEventListener('offline', onOffline)
      window.removeEventListener('beforeinstallprompt', onBeforeInstall)
      window.removeEventListener('appinstalled', onInstalled)
    }
  }, [])

  async function loadNews() {
    try {
      setLoading(true)
      const response = await fetch('/api/news')
      const data = await response.json()
      if (!response.ok || !Array.isArray(data.articles)) throw new Error(data.error || 'Não foi possível carregar as notícias')
      setArticles(data.articles)
      setLastUpdated(data.updatedAt ? new Date(data.updatedAt) : new Date())
      setError('')
    } catch (err) {
      setError(offline ? 'Você está sem conexão. Notícias já carregadas podem continuar disponíveis.' : (err.message || 'Não foi possível atualizar as notícias'))
    } finally {
      setLoading(false)
    }
  }

  const filtered = useMemo(() => articles.filter((article) => {
    const matchesRegion = region === 'Todas' || article.region === region
    const text = `${article.title} ${article.description} ${article.source}`.toLowerCase()
    return matchesRegion && text.includes(query.toLowerCase())
  }), [articles, query, region])

  async function installApp() {
    if (!installPrompt) return
    installPrompt.prompt()
    await installPrompt.userChoice
    setInstallPrompt(null)
  }

  const featured = filtered[0]
  const rest = filtered.slice(1)

  return (
    <main className="site-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar glass">
        <a className="brand" href="/" aria-label="Fatto News início">
          <span className="brand-mark">F</span>
          <span><strong>Fatto</strong><small>NEWS · INFORMAÇÃO EM MOVIMENTO</small></span>
        </a>
        <div className="top-actions">
          {offline && <span className="connection"><WifiOff size={15} /> Offline</span>}
          {installed && <span className="connection"><CheckCircle2 size={15} /> Instalado</span>}
          {installPrompt && <button className="install-button" onClick={installApp}><Download size={16} /> Instalar app</button>}
          <button className="icon-button" onClick={loadNews} aria-label="Atualizar notícias"><RefreshCw size={18} /></button>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="live-dot" /> SEU PONTO DE VISTA</span>
          <h1>O fato importa.<br /><em>Entenda o mundo.</em></h1>
          <p>As notícias que movimentam o Brasil e o mundo, reunidas em uma leitura simples e elegante</p>
          <div className="hero-meta"><span><Globe2 size={15} /> Brasil & Mundo</span><span><Newspaper size={15} /> Fontes identificadas</span></div>
        </div>
        <div className="hero-orb" aria-hidden="true">
          <div className="orb-ring ring-one" /><div className="orb-ring ring-two" />
          <div className="orb-core"><span>F</span><small>FATTO</small></div>
          <div className="orb-chip chip-top">INFORMAÇÃO</div><div className="orb-chip chip-bottom">EM MOVIMENTO</div>
        </div>
      </section>

      <section className="news-section">
        <div className="section-heading">
          <div><span className="eyebrow muted">ACOMPANHE AGORA</span><h2>Últimas notícias</h2></div>
          <span className="updated">{lastUpdated ? `Atualizado às ${lastUpdated.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : 'Atualizações automáticas'}</span>
        </div>

        <div className="controls glass">
          <label className="search-box"><Search size={18} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar notícias..." aria-label="Buscar notícias" /></label>
          <div className="filters" role="group" aria-label="Filtrar notícias">
            {['Todas', 'Brasil', 'Mundo'].map((item) => <button key={item} className={region === item ? 'filter active' : 'filter'} onClick={() => setRegion(item)}>{item}</button>)}
          </div>
        </div>

        {error && <div className="notice">{error} <button onClick={loadNews}>Tentar novamente</button></div>}
        {loading && articles.length === 0 && <div className="loading"><span className="loader" /> Buscando notícias recentes...</div>}
        {!loading && !error && filtered.length === 0 && <div className="empty">Nenhuma notícia encontrada para essa busca</div>}

        {featured && (
          <a className="featured-card glass" href={featured.link} target="_blank" rel="noreferrer">
            <div className="featured-art"><div className="art-grid" /><div className="art-orb" /><span className="art-label">DESTAQUE</span><span className="art-monogram">F.</span></div>
            <div className="featured-content">
              <div className="article-meta"><span className="category">{featured.region}</span><span>{featured.source}</span><span>{formatDate(featured.pubDate)}</span></div>
              <h3>{featured.title}</h3>
              <p>{featured.description || 'Leia a notícia completa na fonte original'}</p>
              <span className="read-link">Ler notícia completa <ArrowUpRight size={16} /></span>
            </div>
          </a>
        )}

        <div className="article-grid">
          {rest.map((article, index) => (
            <a className="article-card glass" href={article.link} target="_blank" rel="noreferrer" key={`${article.link}-${index}`}>
              <div className={`card-art art-${index % 3}`}><span>{article.region === 'Brasil' ? 'BR' : 'MUNDO'}</span><div className="mini-orb" /></div>
              <div className="card-body">
                <div className="article-meta"><span className="category">{article.region}</span><span>{formatDate(article.pubDate)}</span></div>
                <h3>{article.title}</h3>
                <p>{article.description}</p>
                <div className="card-footer"><span>{article.source}</span><ArrowUpRight size={16} /></div>
              </div>
            </a>
          ))}
        </div>

        {loading && articles.length > 0 && <p className="refreshing">Atualizando notícias…</p>}
        <div className="source-note">As notícias e seus direitos pertencem às fontes originais. Ao selecionar uma matéria, você será direcionado ao site da publicação.</div>
      </section>

      <footer><a className="footer-brand" href="/">FATTO NEWS</a><span>Informação em movimento</span><span>© {new Date().getFullYear()} Fatto News</span></footer>
    </main>
  )
}

function formatDate(value) {
  if (!value) return 'Agora'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return 'Agora'
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })
}

createRoot(document.getElementById('root')).render(<App />)
